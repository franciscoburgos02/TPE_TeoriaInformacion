import random
from paq_tpe import matriz_canal, Fuente

def probabilidad_experimento(entrada, salida, j, n, it_min, umbral):
    """
    Mediante simulacion computacional, retorna la probabilidad de que, al aparecer el simbolo
    j en la salida del canal, los siguientes k (hasta n) elementos sean distintos a este.
    """
    funcion_conv = []
    mat_c = matriz_canal(entrada, salida)
    mat_p = entrada.matriz_pasaje()
    ind_s = {v: i for i, v in enumerate(entrada.simbolos())}
    prob, prob_ant, exitos, iteraciones = 0, -1, 0, 1

    while iteraciones < it_min or abs(prob_ant - prob) > umbral: 
        s_entrada = random.choices(entrada.simbolos(), entrada.vector_estacionario(), k = 1)[0] #primer simbolo en la entrada
        s_salida = random.choices(entrada.simbolos(), mat_c[:, ind_s[s_entrada]])[0] #salida del canal para la entrada s
        while s_salida != j: # para simulación mas fiel
            s_entrada = random.choices(entrada.simbolos(), mat_p[:, ind_s[s_entrada]] , k = 1)[0]
            s_salida = random.choices(entrada.simbolos(), mat_c[:, ind_s[s_entrada]] , k = 1)[0]    
        suma = 0
        while s_salida == j:
            s_entrada = random.choices(entrada.simbolos(), mat_p[:, ind_s[s_entrada]] , k = 1)[0]
            s_salida = random.choices(entrada.simbolos(), mat_c[:, ind_s[s_entrada]] , k = 1)[0]
            if (s_salida == j):
                if (suma <= n):
                    exitos += 1
                break
            suma += 1
        
        iteraciones += 1
        prob_ant = prob
        prob = exitos / iteraciones if iteraciones > 0 else 0
        funcion_conv.append(abs(prob_ant - prob) if prob != 0 else 0)
    return funcion_conv, round(prob, 3)