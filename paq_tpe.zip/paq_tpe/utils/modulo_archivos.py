import os
import numpy as np

def file_to_array(ruta):
    'Pasa el contenido del archivo a un arreglo'
    return np.loadtxt(ruta, dtype = int)

def array_to_file(ruta, arr):
    'Genera un archivo a partir del arreglo dado'
    with open(ruta, "w") as archivo:
        for item in arr:
            archivo.write(item)
    return ruta