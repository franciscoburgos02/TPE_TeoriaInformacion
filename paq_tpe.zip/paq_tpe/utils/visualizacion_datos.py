import matplotlib.pyplot as plt
import pandas as pd

def df_matriz(matriz, columna, fila):
    'Genera un DataFrame Matriz'
    return pd.DataFrame(matriz, columns = columna, index = fila)
    
def df_tabla(indices, valores) -> pd.DataFrame:
    'Genera un DataFrame Tabla'
    if len(indices) != len(valores):
        raise ValueError("Las listas de índices y valores deben tener la misma longitud")
    else:
        return pd.DataFrame({indices[i]: valores[i] for i in range(len(indices))})
    
def df_diccionario(dicc, indice):
    'Genera un DataFrame Diccionario'
    return pd.DataFrame(dicc, index = [indice])

def mostrar_df(dfs: list):
    'Muestra dataframes creados con pandas'
    n_dfs = len(dfs)
    cols = 1
    tablas = n_dfs
    fig, axs = plt.subplots(tablas, cols, figsize=(4, 2 * n_dfs))
    fig.patch.set_facecolor("white")
    if n_dfs == 1:
        axs = [axs]
    for i, df in enumerate(dfs):
        ax = axs[i]
        ax.xaxis.set_visible(False)
        ax.yaxis.set_visible(False)
        ax.set_frame_on(False)
        tabla = ax.table(cellText=df.values, colLabels=df.columns, cellLoc='center', loc='center')
        tabla.auto_set_font_size(True)
        tabla.set_fontsize(12)
        tabla.scale(1.0, 1.4)
        ax.set_position([0, 0, 1, 1])
    fig.subplots_adjust(left=0, right=1, top=1, bottom=0.1, hspace=0.1)
    plt.show()