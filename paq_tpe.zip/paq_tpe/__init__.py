from .huffman import huffman, archivo_compresion, long_promedio, tasa_de_compresion
from .utils import mostrar_df, df_diccionario, df_matriz, df_tabla, file_to_array, array_to_file
from .calculo import Fuente, media, desvio, mayor_factor_correlacion_cruzada, entropia_condicional, entropia_sin_memoria, ruido, informacion_mutua, matriz_canal
from .simulacion import probabilidad_experimento