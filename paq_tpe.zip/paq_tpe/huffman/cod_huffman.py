import heapq
from .nodo import Nodo

def heap_nodos(simbolos, estacionario):
    'Genera una cola de prioridad con un nodo por cada simbolo y su probabilidad'
    nodos = [Nodo(p, None, None, s) for s, p in zip(simbolos, estacionario)]
    heapq.heapify(nodos)
    return nodos

def lectura_arbol(arbol, codigo, codificacion):
    'A partir del arbol genera un diccionario con los simbolos y su codigo correspondiente'
    if arbol is not None:
        if arbol.simbolo() is not None:
            codificacion[arbol.simbolo()] = codigo
        lectura_arbol(arbol.izquierda(), codigo + '0', codificacion)
        lectura_arbol(arbol.derecha(), codigo + '1', codificacion)
    return codificacion

def huffman(simbolos, estacionario):
    'Huffman para compresion: devuelve un diccionario con el codigo y la longitud promedio'
    # genero un arreglo con las hojas
    arbol = heap_nodos(simbolos, estacionario)
    # construcción del árbol
    while len(arbol) > 1:
        n1 = heapq.heappop(arbol) # tomo los 2 primeros elementos de la cola
        n2 = heapq.heappop(arbol)
        n0 = Nodo(n1.probabilidad() + n2.probabilidad(), n1, n2) # los añado como hijos de un nuevo nodo
        heapq.heappush(arbol, n0)
    # se construye la codificación a partir del árbol
    return lectura_arbol(arbol[0], '', {})
