def long_promedio(codificacion, distribucion):
    'Calcula la longitud promedio de la codificacion'
    suma = 0
    for s, p in distribucion:
        suma += len(codificacion[s]) * p
    return suma
