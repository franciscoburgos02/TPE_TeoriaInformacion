class Nodo:
    'Arbol necesario para el algoritmo de Huffman'
    def __init__(self, prob, izq= None, der= None, simb= None):
        self.izq = izq
        self.der = der
        self.simb = simb
        self.prob = prob

    def probabilidad(self):
        'Retorna la probabilidad'
        return self.prob

    def izquierda(self):
        'Retorna el nodo hijo izquierdo'
        return self.izq

    def derecha(self):
        'Retorna el nodo hijo derecho'
        return self.der

    def simbolo(self):
        'Retorna el simbolo correspondiente'
        return self.simb

    def __lt__(self, otro):
        'Define el criterio de ordenamiento'
        return self.probabilidad() < otro.probabilidad()
    