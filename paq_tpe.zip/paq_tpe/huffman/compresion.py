import os

def codificacion_ord1(snl, codificacion: dict):
    'Realiza la codificación de una señal (Orden 1)'
    arr_binario = [codificacion[i] for i in snl]
    return ''.join(arr_binario)

def codificacion_ord2(snl, codificacion: dict):
    'Realiza la codificación de una señal (Orden 2)'
    arr_binario = [codificacion[i + j] for i, j in zip(snl[::2], snl[1::2])]
    return ''.join(arr_binario)

def archivo_compresion(ruta: str, snl, codificacion: dict, orden: int):
    """
    Copia el archivo con la compresion dada por el codigo.
    Es representativo por lo que no se obtendran los mismos datos que en el
    original.
    """
    if orden == 1:
        string_binario = codificacion_ord1(snl, codificacion)
    else:
        string_binario = codificacion_ord2(snl, codificacion)
    arr_bytes = bytearray()
    for i in range(0, len(string_binario), 8):
        byte = string_binario[i:i+8] # toma 8 elementos del string para generar un byte
        arr_bytes.append(int(byte.ljust(8, '0'), 2))  # Relleno con ceros a la derecha si no alcanza
    with open(ruta, "wb") as archivo: #indica que escribe como binario
        archivo.write(arr_bytes)
    return ruta

def tasa_de_compresion(original: str, comprimido: str):
    'Toma a rutas a dos archivos para comparar su tamaño y devolver la tasa de compresion'
    o = os.path.getsize(original)
    c = os.path.getsize(comprimido)
    return round(o / c, 3)
