import math

def media(arr):
    'Retorna la media de la señal.'
    m = 0
    for v in arr:
        m += v
    return round(m / len(arr), 3)

def desvio(arr):
    'Retorna la dispersión de los valores de la señal respecto de la media'
    m = media(arr)
    suma = 0
    for v in arr:
        suma += (v - m)**2
    return round(math.sqrt(suma / len(arr)), 3)

def factor_correlacion_cruzada(arr1, arr2):
    'Retorna la correlacion cruzada entre la señal brindada por arr1 y la señal brindada por arr2.'
    m1 = media(arr1)
    m2 = media(arr2)
    suma = 0
    d1 = 0
    d2 = 0
    for v1, v2 in zip(arr1, arr2):
        suma += ((v1 - m1) * (v2 - m2))
        d1 += (v1 - m1)**2
        d2 += (v2 - m2)**2
    return round(suma / math.sqrt(d1 * d2), 3)