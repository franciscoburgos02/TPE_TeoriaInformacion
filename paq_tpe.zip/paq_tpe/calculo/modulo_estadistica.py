import math

def media(arr):
    'Retorna la media de la señal.'
    m = 0
    for v in arr:
        m += v
    return round(m / len(arr), 3)

def desvio(arr):
    'Retorna la dispersión de los valores de la señal respecto de la media'
    m = media(arr)
    suma = 0
    for v in arr:
        suma += (v - m)**2
    return round(math.sqrt(suma / len(arr)), 3)

def covarianza_cruzada(arr1, arr2):
    'Devuelve la covarianza cruzada entre 2 señales para cada desplazamiento'
    covarianza = []
    m_arr1 = media(arr1)
    m_arr2 = media(arr2)
    long = len(arr1)
    for desplazamiento in range(- long + 1, long):
        sum_s1s2 = 0
        for i in range(long):
            if 0 <= i + desplazamiento < long:
                # se le resta la media a cada valor de correlacion
                sum_s1s2+= (arr1[i] - m_arr1) * (arr2[i + desplazamiento] - m_arr2)
        covarianza.append(sum_s1s2 / long)
    return covarianza

def factor_correlacion_cruzada(arr1, arr2):
    'Devuelve el factor de correlación cruzada para cada desplazamiento'
    d1 = desvio(arr1)
    d2 = desvio(arr2)
    cov = covarianza_cruzada(arr1, arr2)
    # se divide cada valor por el producto entre desvios las señales.
    return [c / (d1 * d2) for c in cov]

def mayor_factor_correlacion_cruzada(arr1, arr2):
    'Retorna el valor mas alto de correlación entre las 2 señales'
    f = factor_correlacion_cruzada(arr1, arr2)
    maxf, minf = max(f), min(f)
    if abs(maxf) > abs(minf):
        return maxf
    return minf

def factor_correlacion_pearson(arr1, arr2):
    'Retorna la correlacion lineal entre la señal brindada por arr1 y la señal brindada por arr2.'
    m1 = media(arr1)
    m2 = media(arr2)
    suma = 0
    d1 = 0
    d2 = 0
    for v1, v2 in zip(arr1, arr2):
        suma += ((v1 - m1) * (v2 - m2))
        d1 += (v1 - m1)**2
        d2 += (v2 - m2)**2
    return round(suma / math.sqrt(d1 * d2), 3)