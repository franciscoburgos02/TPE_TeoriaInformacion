import numpy as np
from .modulo_entropia import entropia_sin_memoria, entropia_condicional
from .fuente import Fuente

def matriz_canal(entrada, salida):
    'Calcula la matriz de canal entre una señal de entrada y una de salida'
    n = entrada.cantidad_simbolos()
    mat = np.zeros((n, n), dtype = float)
    # sumo las ocurrencias
    indice = {s: i for i, s in enumerate(entrada.simbolos())}
    for s1, s2 in zip(entrada, salida):
        i1 = indice[s1]
        i2 = indice[s2]
        mat[i1, i2] += 1
    # la vuelvo una matriz de probabilidades dividiendo por la suma de cada fila
    for i in range(n):
        suma = np.sum(mat[i, :])
        if suma > 0:
            mat[i, :] = np.round(mat[i, :] / suma, decimals = 3)
    return mat.T

def ruido(entrada, salida):
    'Retorna el ruido de un canal'
    probsx = entrada.vector_estacionario()
    mat_canales = matriz_canal(entrada, salida)
    return entropia_condicional(mat_canales, probsx)

def informacion_mutua(entrada, salida):
    """
    Calcula la informacion mutua I(X, Y) = H(X) + H(Y) - H(X, Y)
    pero H(X, Y) = H(X) + H(Y/X)
    entonces I(X, Y) = H(Y) - H(Y/X)
    """
    estacionario_y = salida.vector_estacionario()
    hy = entropia_sin_memoria(estacionario_y)
    return round(hy - ruido(entrada, salida), 3)