import math

def entropia_sin_memoria(vector_est):
    'Retorna la entropía calculada a partir de la distribucion de probabilidad estacionaria'
    entropia = 0
    # cálculo de la entropía
    for p in vector_est:
        if (p != 0):
            entropia += p * math.log(p, 2)
    return - round(entropia, 3)

def entropia_condicional(matriz, vector_est):
    'Retorna la entropía calculada a partir de una matriz condicional (canal o pasajes) y un vector de probabilidades'
    entropia = 0
    # cálculo de la entropía utilizando formula de entropia condicionada
    for i, p_i in enumerate(vector_est):
        e = entropia_sin_memoria(matriz[:, i])
        entropia += e * p_i
    return round(entropia, 3)