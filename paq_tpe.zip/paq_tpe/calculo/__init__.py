from .fuente import Fuente
from .modulo_canal import  matriz_canal, ruido, informacion_mutua
from .modulo_entropia import entropia_sin_memoria, entropia_condicional
from .modulo_estadistica import media, desvio, mayor_factor_correlacion_cruzada
