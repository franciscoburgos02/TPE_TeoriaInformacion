import numpy as np

class Fuente:
    'Clase Fuente'
    def __init__(self, arr):
        self.senal = ['A' if v >= 20 else 'B' if v < 10 else 'M' for v in arr]
        self.indice = 0
        self.s = None
        self.l = None
        self.s_ord2 = None
        self.s_cant = None
        self.m_pasaje = None
        self.ve = None
        self.ve_ord2 = None

    def __iter__(self):
        self.indice = 0
        return self
    
    def __next__(self):
        if self.indice < self.long():
            resultado = self.senal[self.indice]
            self.indice += 1
            return resultado
        else:
            raise StopIteration
        
    def __getitem__(self, indice):
        return self.senal[indice]
           
    def __calculo_long(self):
        'Calcula la longitud de la señal'
        return len(self.senal)
    
    def __calculo_simbolos(self):
        'Calcula un array con los simbolos que contiene la señal'
        return np.unique(self.senal)
    
    def __calculo_simbolos_orden_2(self):
        'Calcula un array con los simbolos que contiene la señal para orden 2'
        simbolos = self.simbolos()
        return np.array([s1 + s2 for s1 in simbolos for s2 in simbolos])
    
    def __calculo_cantidad_simbolos(self):
        'Calcula la cantidad de simbolos distintos que hay en la señal'
        return len(self.simbolos())
    
    def __calculo_matriz_pasaje(self):
        'Calcula la matriz de pasajes de la fuente.'
        simbolos = self.simbolos()
        n = self.cantidad_simbolos()
        mat = np.zeros((n, n))
        lim = self.long() - 1
        indice = {valor: i for i, valor in enumerate(simbolos)}
        # cuenta las ocurrencias de cada pasaje
        for i in range(lim):
            j = indice[self.senal[i]]
            k = indice[self.senal[i + 1]]
            mat[j][k] += 1
        # hace el calculo de las probabilidades
        for i in range(n):
            suma = np.sum(mat[i, :])
            if suma > 0:
                mat[i, :] = np.round(mat[i, :] / suma, decimals = 3)
        return mat.T
    
    def __calculo_vector_estacionario(self):
        'Calcula el vector de probabilidades estacionarias de la señal'
        lim = self.cantidad_simbolos()
        # le resto a la matriz de pasajes la matriz identidad
        mat = (self.matriz_pasaje() - np.identity(lim))
        #cambio por unos la ultima fila ya que solo necesito 2 de la matriz original para el sistema
        mat[lim - 1, :] = 1
        # genero el vector de igualdad
        resultados = np.zeros(lim)
        resultados[-1] = 1
        return np.round(np.linalg.solve(mat, resultados), decimals = 3)
    
    def __calculo_vector_estacionario_orden2(self):
        'Calcula el vector de probabilidades estacionarias de la señal para orden 2'
        p_ord1 = self.vector_estacionario()
        mat = self.matriz_pasaje()
        return np.round((p_ord1 * mat).flatten(), decimals = 3)
    
    def long(self):
        'Retorna la longitud de la señal'
        if self.l is None:
            self.l = self.__calculo_long()
        return self.l
    
    def simbolos(self):
        'Retorna un array con los simbolos que contiene la señal'
        if self.s is None:
            self.s = self.__calculo_simbolos()
        return self.s
    
    def simbolos_orden_2(self):
        'Retorna un array con los simbolos que contiene la señal para orden 2'
        if self.s_ord2 is None:
            self.s_ord2 = self.__calculo_simbolos_orden_2()
        return self.s_ord2
    
    def cantidad_simbolos(self):
        'Retorna la cantidad de simbolos distintos que hay en la señal'
        if self.s_cant is None:
            self.s_cant = self.__calculo_cantidad_simbolos()
        return self.s_cant
    
    def matriz_pasaje(self):
        'Retorna la matriz de pasajes de la fuente.'
        if self.m_pasaje is None:
            self.m_pasaje = self.__calculo_matriz_pasaje()
        return self.m_pasaje
    
    def vector_estacionario(self):
        'Devuelve el vector de probabilidades estacionarias de la señal'
        if self.ve is None:
            self.ve = self.__calculo_vector_estacionario()
        return self.ve
    
    def vector_estacionario_orden2(self):
        'Devuelve el vector de probabilidades estacionarias de la señal para orden 2'
        if self.ve_ord2 is None:
            self.ve_ord2 = self.__calculo_vector_estacionario_orden2()
        return self.ve_ord2